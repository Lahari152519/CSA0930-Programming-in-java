# Java
## Expt 1:
![1](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/0259c97a-35f8-49e2-ba0d-044579975384)

## Expt 2:
![2](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/9b8b6469-a5ab-4eb2-a282-db051c5b4954)




## Expt 4:
![4](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/fb2b7ed6-3c3f-46e4-91be-198e1cf6d777)

## Expt 5:
![5](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/5c3ce4b7-3213-4c21-8264-5ef31c8871d2)

## Expt 6:
![6](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/708101de-dca8-4f33-b45e-eedffcfe3894)

## Expt 7:
![7](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/fea4b9d4-f09a-40c9-8deb-213291745340)

## Expt 8:
![8](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/6aa867fa-0d0a-4b1d-8353-98b098d9cc0d)

## Expt 9:
![9](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/6fc02c8b-5f86-4b16-8875-66323c3d65cd)

## Expt 10:
![10](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/b1ea7c59-87a4-44d3-a9fd-021d0675a3fe)

## Expt 11:
![11](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/2276929e-bb3f-413c-98d4-240056e6de54)

## Expt 12:
![12](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/626b33f4-653b-45f3-b0e4-5a34eea0f2d7)

## Expt 13:
![13](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/96008359-599f-495c-a12d-5a3b0626609c)

## Expt 14:
![14](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/15f2cf9a-2c1d-4230-b7d1-6df90f61878c)

## Expt 15:
![15](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/8d311c21-ae58-4678-8deb-b9bc0f472a42)

## Expt 16:
![16](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/9d5cd880-8b04-488b-8b07-0de0b0a2c388)

## Expt 17:
![17](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/3eb3257a-2226-4b07-af48-3c5106865fb0)

## Expt 18:
![18](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/5b29dc32-10ed-4f2c-ae06-dffb49671c4b)

## Expt 19:
![19](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/0ed1054b-79e7-4383-a5bb-9bf883e07eeb)

## Expt 20:
![20](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/d0c37a7d-87a8-45eb-a314-7273abe7ce3e)

## Expt 21:
![21](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/5a43b76a-78f8-4638-8b3d-3346ec76afe3)

## Expt 22:
![22](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/8f86c57f-d6b7-48bb-81b2-553423c1a423)

## Expt 23:
![23](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/217b0b83-93ea-4be0-b69a-581af864f261)

## Expt 24:
![24](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/bc2c6c31-2f88-48a9-8f10-1a5a0ea0b326)

## Expt 25:
![25](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/8914762d-7dac-44a2-ab56-0a5310b34da4)

## Expt 26:
![26](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/ba44f201-322e-4a04-9c40-211ec98c976a)

## Expt 27:
![27](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/f5fcc2b2-b35e-4ba5-950a-25b2d928b6c0)

## Expt 28:
![28](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/7cea8fad-7a22-402d-a35e-dbdf7759228b)

## Expt 29:

![29](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/93ab22f7-abf7-4003-9e43-2ffc260de85c)

## Expt 30:

![30](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/bd3bc7c7-7538-4c3e-ab27-dfdd305d3bda)

## Expt 31:

![31](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/e455c2a7-c58f-4868-8115-3342b511478e)

## Expt 32:

![32](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/74e9469f-3def-42bf-aa9a-29219ff738b5)

## Expt 33:

![33](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/d0feb464-ed1b-4615-831f-c7e9c35b374d)

## Expt 34:

![34](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/a579ffc1-d3e7-433a-996d-0b63069e8a40)

## Expt 35:

![35](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/a320adcf-9c36-47e8-a185-df1bb4d1fc36)

## Expt 36:

![36](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/4c290401-a3b2-48c8-93b2-70126b7d5476)

## Expt 37:

![37](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/81e10ff7-70f8-4356-9518-43d273243b9f)

## Expt 38:

![38](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/a1f79f62-6c09-4f22-832f-ec31b11cb50f)

## Expt 39:

![39](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/fab6f6e7-8482-433f-b0ac-6c5446fe9283)

## Expt 40:

![40](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/fcbfcee4-928a-4fee-bdcc-eefbd49c6822)

## Expt 41:
![41](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/e4aa452a-9793-4ea7-b5b9-82ec46908226)

## Expt 42:
![42](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/96001393-d3b8-4714-9b09-d3fa705edeec)

## Expt 43:
![43](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/ace234e3-bc15-42bb-a20f-329bd9dbf1e7)

## Expt 44:
![44](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/ce6e4e25-18c7-4585-b460-4a569a339d1d)

## Expt 45:
![45](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/2e7d2bfe-6b21-4e3c-b695-16ac91db127c)

## Expt 46:
![46](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/3802b3ec-3038-4049-8cc9-e2067c7ffe95)

## Expt 47:
![47](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/9fbb9ae0-70b6-44e9-814a-c644d1dabbba)

## Expt 48:
![48](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/3f94d2d8-21ef-4982-bdfd-a91d458e1e1f)

## Expt 49:
![49](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/b7476f49-ba14-490d-a7a7-cb21c23a2bc4)

## Expt 50:
![50](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/cd7cd2aa-585b-40c8-9d00-655eb2ec6810)

## Expt 51:
![51](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/49c61b83-e8f3-45e4-837c-44de0140b7bf)

## Expt 52:
![52](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/5783d863-2877-4283-84de-fc3f100805ec)

## Expt 53:
![53](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/ab1e8cff-2cc1-4885-84ee-6fb723332724)

## Expt 54:
![54](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/21d353da-b467-496e-91e5-f567e17e5ebc)

## Expt 55:
![55](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/ae3b0196-7c45-4cb1-807a-74ccc9332048)

## Expt 56:
![56](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/b8e5a248-ca0e-4596-bcf9-4562b98716bb)

## Expt 57:
![57](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/15ffc6c8-f65a-4a4e-8c27-983fafa4c304)

## Expt 58:
![58](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/96024ccc-ff80-475e-a1df-88974ef6544d)

## Expt 59:
![59](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/a3ca98da-0f1f-40b3-b1c3-65d451825a73)

## Expt 60:
![60](https://github.com/DevadarshiniJayamurugan/Java/assets/100745306/1a35f0b3-4b03-4d04-b780-6a07e2d83ce3)

_______________________________________________________________________________________________________________________________________________________________________
